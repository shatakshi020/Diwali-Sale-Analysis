# DataAnalysis_DiwaliSales
Analyzing sales of product during Diwali Fest by the data of a brand that I got from Kaggle.com. I used the numpy, pandas, matplotlib, and seaborn libraries of python.
